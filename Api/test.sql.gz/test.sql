-- MySQL dump 10.13  Distrib 5.6.50, for Linux (x86_64)
--
-- Host: localhost    Database: register
-- ------------------------------------------------------
-- Server version	5.6.50-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `gender` int(11) NOT NULL DEFAULT '1',
  `email` varchar(50) DEFAULT NULL,
  `grade` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES (1,'超级管理员','123456','E50DE14051AFD6AACD8D1560F2F08579',1,NULL,1),(2,'墨羽晨','12345678','78d609a308db4a83d77eac6f9d486262',0,'3216354195@qq.com',1);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arrange`
--

DROP TABLE IF EXISTS `arrange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arrange` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doctorName` varchar(10) NOT NULL,
  `doctorId` int(11) NOT NULL,
  `hosName` varchar(30) DEFAULT NULL,
  `hosId` int(11) NOT NULL,
  `depName` varchar(30) NOT NULL,
  `depTwoId` int(11) NOT NULL,
  `time` date DEFAULT NULL COMMENT '日期',
  `MtimeSegment` varchar(20) DEFAULT NULL COMMENT '上午时间段',
  `Mnum` int(11) DEFAULT '10',
  `Msurplus` int(11) DEFAULT '10' COMMENT '剩余数量',
  `Mstate` int(11) DEFAULT '0' COMMENT '0排班，1休息',
  `AtimeSegment` varchar(20) DEFAULT NULL COMMENT '下午时间段',
  `Anum` int(11) DEFAULT '10',
  `Asurplus` int(11) DEFAULT '10' COMMENT '剩余数量',
  `Astate` int(11) DEFAULT '0' COMMENT '0排班，1休息',
  PRIMARY KEY (`id`),
  KEY `doctorId` (`doctorId`,`doctorName`,`depName`,`depTwoId`,`time`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arrange`
--

LOCK TABLES `arrange` WRITE;
/*!40000 ALTER TABLE `arrange` DISABLE KEYS */;
INSERT INTO `arrange` VALUES (1,'吴雨涵',1,'华夏神州人民医院青龙东院',1,'内科-神经内科',1,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(2,'沈林',2,'华夏神州人民医院青龙东院',1,'内科-消化内科',2,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(3,'贾美欣',11,'华夏神州人民医院青龙东院',1,'外科-心血管外科',3,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(4,'谢桂英',12,'华夏神州人民医院青龙东院',1,'外科-心血管外科',3,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(5,'武天昊',14,'华夏神州人民医院青龙东院',1,'外科-烧伤科',4,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(6,'陆超',13,'华夏神州人民医院青龙东院',1,'外科-骨外科',5,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(8,'陆欣汝',3,'华夏神州人民医院厚土中院',2,'内科-内分泌科',7,'2022-08-18','09.25-11.25',10,10,0,'14.25-17.25',10,10,0),(9,'徐润莎',8,'华夏神州人民医院玄武北院',3,'中医科-中医全科',13,'2022-08-18','10.40-11.40',10,10,0,'14.40-15.40',10,10,0),(10,'陈强',9,'华夏神州人民医院玄武北院',3,'中医科-中医儿科',14,'2022-08-18','10.40-11.40',10,10,0,'14.40-15.40',10,10,0),(11,'徐榕润',7,'华夏神州人民医院厚土中院',2,'内科-内分泌科',7,'2022-08-18','10.40-11.40',10,10,0,'14.40-15.40',10,10,0),(12,'阎苒溪',10,'华夏神州人民医院厚土中院',2,'眼科-眼部外科',10,'2022-08-18','10.40-11.40',10,10,0,'14.40-15.40',10,10,0),(13,'任晓庆',6,'华夏神州人民医院玄武北院',3,'内科-普通内科',11,'2022-08-23','08.55-11.55',10,10,0,'13.55-16.55',10,10,0),(14,'任晓庆',6,'华夏神州人民医院玄武北院',3,'内科-普通内科',11,'2022-08-25','08.55-11.55',10,10,0,'13.55-16.55',10,10,0),(15,'秦雅涵',5,'华夏神州人民医院玄武北院',3,'内科-普通内科',11,'2022-08-25','08.55-11.55',10,8,0,'0',10,10,1),(16,'秦雅涵',5,'华夏神州人民医院玄武北院',3,'内科-普通内科',11,'2022-08-26','0',10,10,1,'13.55-18.30',10,10,0);
/*!40000 ALTER TABLE `arrange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `readNum` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL,
  `author` varchar(20) NOT NULL DEFAULT '佚名',
  `cat` varchar(50) NOT NULL DEFAULT '分享',
  `imgUrl` varchar(50) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `content` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `article_cat` (`cat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,11,'【医院营销】开启新时代医院营销方式','现代医院院长网','健康百科','/images/article/imgUrl-1660737111596.jpg','2022-08-17 19:51:51','<p><span style=\"color: rgb(51, 51, 51);\">在这个充满挑战与竞争的医疗市场环境中，满足患者的需求，成为医疗市场营销目标。以人为本的市场营销是现代关系的营销思想中的核心思想，全体员工都应该积极参与医疗机构市场营销，最大空间的拓展市场，收获最大利润</span></p><p><br></p><p><strong style=\"color: rgb(51, 51, 51);\"><span class=\"ql-cursor\">﻿</span>如何提升医院营销效果？</strong></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><strong style=\"color: rgb(51, 51, 51);\">1.树立全员营销意识</strong></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">一方面，纠正全体员工对医院市场营销的表面看法，加强员工对市场营销的认识，了解市场营销的重要性，即医院的市场营销就是有目的性的宣传医院。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">打响医院的知名度，是医疗行业拓展业务的的重要手段之一，密切关系着医患关系，这样有效地增加了医院的经济效益和凝聚力。只有不断加强全体员工的市场营销观念，才能真正地认同并支持医院有效地开展营销活动。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">另一方面，树立全体员工的营销意识。医院应该定期举行培训活动，树立员工的营销意识，让员工认识到营销不仅仅是营销人员的任务，还需要全体员工的配合与参与。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">因为在医疗服务过程中，医务人员接触患者的时间远远多于营销人员的时间，因此更需要医务人员具备营销意识，各个部门之间互相协助，落实营销策略，提升优质服务质量，共同创造医院的价值。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><strong style=\"color: rgb(51, 51, 51);\">2.细分医疗服务市场</strong></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">市场细分是医院正确制定营销策略和选择适当目标市场的重要依据,是确保自身实现其经营目标的基础。市场细分的依据就是客观存在的需求差异性。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">存在的差异性变化多端的，还没有一个完整的市场细分标准模式。在一般情况下，较为常见制约因素有：地理位置、年龄差异、消费者的消费观念、心理因素等。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">医院全体员工可以根据消费者的不同情况细分市场，如按地理位置划分，可以分为省级医院、市级医院、地方医院市场。</span></p><p><span style=\"color: rgb(51, 51, 51);\">&nbsp;</span></p><p><span style=\"color: rgb(51, 51, 51);\">进行市场明细分后，医院可以根据以往病人地理结构以及医院的特殊性，选择好市场，采用无差异化策略、目标积聚策略等开展具有针对性的市场营销活动。</span></p>'),(2,7,'医院营销核心是？让患者体验到高质量就医服务','张院长','分享','/images/article/imgUrl-1660737479739.png','2022-08-17 19:57:59','<p class=\"ql-align-justify\">现在的营销理念是什么，是以患者为出发点而不是医院。重要点是患者所需要的治疗服务，目的是通过患者满意度获得利润，而不是通过增加患者获得利润。</p><p class=\"ql-align-justify\">如今大多数的医院都还是执行等患者上门求医，还是以医院为中心，而不是以患者的角度提供相应的服务。</p><p class=\"ql-align-justify\">医院的形象和荣誉在一定程度上决定了医院对患者的吸引力。</p><p class=\"ql-align-justify\">因此，医院必须千方百计提髙整体形象，通过医院形象创建科学、规范、温馨和充满人性化的理念、视觉和行为识别标志，从而提高医院在人民群众中的良好形象，以形象力来推动经营力。</p><p class=\"ql-align-justify\">&nbsp;</p><p class=\"ql-align-justify\"><strong>一、医院的形象营销</strong></p><p class=\"ql-align-justify\">1、事件营销</p><p class=\"ql-align-justify\">要充分利用各种突发事件、重大事件或大众传媒关注的事件进行营销。</p><p class=\"ql-align-justify\">医院可通过为广大群众进行防病治病知识的宣传、提供咨询服务、免费发放口罩或预防性药品等，来扩大医院影响力，提高医院在群众中的声誉，这就是所谓的“危难见真情”。</p><p class=\"ql-align-justify\">2、&nbsp;&nbsp;会议营销</p><p class=\"ql-align-justify\">医院可通过承办一些学术交流会，以及继续教育学习班、专业证书班等，扩大医院影响。</p><p class=\"ql-align-justify\">3、&nbsp;&nbsp;公益营销</p><p class=\"ql-align-justify\">医院可通过组织义诊、免费健康咨询、为老年人进行免费健康检查、举办免费健康教育讲座等活动，来吸引公众的注意力，增加医院的知名度。</p><p class=\"ql-align-justify\"><br></p><p class=\"ql-align-justify\"><strong>二、环境与隐私</strong></p><p class=\"ql-align-justify\">1、注意保护患者隐私</p><p class=\"ql-align-justify\">门诊部应设计单人诊室；注射室和各种医技检查均应设单间或分隔遮帘;住院部应进一步向少床或单床病房发展。</p><p class=\"ql-align-justify\">在北京的一些中外合作医院，每位患者都可以单独享用诊室，不得到患者和医生的允许，任何人不得进人诊室。</p><p class=\"ql-align-justify\">2、&nbsp;&nbsp;布置温馨宜人的环境</p><p class=\"ql-align-justify\">应用美学和行为心理学的研究成果来进行室内环境设计，避免产生单调乏味甚至冷冰冰的室内空间环境。</p><p><br></p>'),(3,6,'预约挂号小程序上线','管理员','公告','/images/article/imgUrl-1660737708781.jpg','2022-08-17 20:01:48','<p>触摸智慧生活现已上线，预约挂号小程序，可在小程序进行预约挂号，选择医生时间点提交挂号。</p>');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `code`
--

DROP TABLE IF EXISTS `code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` char(6) NOT NULL,
  `time` varchar(13) DEFAULT NULL COMMENT '操作开始时间戳',
  `state` int(11) DEFAULT '1' COMMENT '1表示操作中，2表示已失效',
  `uid` int(11) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `code`
--

LOCK TABLES `code` WRITE;
/*!40000 ALTER TABLE `code` DISABLE KEYS */;
INSERT INTO `code` VALUES (1,'124009','1660804953',2,1,'749038898@qq.com'),(2,'584921','1660962943',2,1,'749038898@qq.com'),(3,'045992','1660963165',2,1,'749038898@qq.com');
/*!40000 ALTER TABLE `code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depHospital`
--

DROP TABLE IF EXISTS `depHospital`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depHospital` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `minname` varchar(6) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `state` int(11) DEFAULT '1' COMMENT '开关，0表示关闭',
  PRIMARY KEY (`id`),
  KEY `state` (`state`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depHospital`
--

LOCK TABLES `depHospital` WRITE;
/*!40000 ALTER TABLE `depHospital` DISABLE KEYS */;
INSERT INTO `depHospital` VALUES (1,'青龙东院','华夏神州人民医院青龙东院',1),(2,'厚土中院','华夏神州人民医院厚土中院',1),(3,'玄武北院','华夏神州人民医院玄武北院',1);
/*!40000 ALTER TABLE `depHospital` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depInclude`
--

DROP TABLE IF EXISTS `depInclude`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depInclude` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `depId` int(11) NOT NULL COMMENT '所属科室id',
  `hosId` int(11) NOT NULL COMMENT '分院id',
  `depName` varchar(50) DEFAULT NULL COMMENT '科室名称',
  `name` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL COMMENT '楼层地址',
  `state` int(11) DEFAULT '1' COMMENT '开关，0表示关闭',
  PRIMARY KEY (`id`),
  KEY `state` (`state`,`depId`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depInclude`
--

LOCK TABLES `depInclude` WRITE;
/*!40000 ALTER TABLE `depInclude` DISABLE KEYS */;
INSERT INTO `depInclude` VALUES (1,1,1,'内科','神经内科','内科大楼203',1),(2,1,1,'内科','消化内科','内科大楼201',1),(3,2,1,'外科','心血管外科','外科大楼225',1),(4,2,1,'外科','烧伤科','外科大楼556',1),(5,2,1,'外科','骨外科','外科大楼356',1),(6,11,2,'内科','神经内科','急诊大楼105',1),(7,11,2,'内科','内分泌科','内科大楼236',1),(8,12,2,'外科','普通外科','外科大楼586',1),(9,12,2,'外科','神经外科','外科大楼886',1),(10,15,2,'眼科','眼部外科','外科大楼446',1),(11,20,3,'内科','普通内科','内科大楼113',1),(12,20,3,'内科','肾内科','内科大楼259',1),(13,28,3,'中医科','中医全科','中医院6号楼225',1),(14,28,3,'中医科','中医儿科','中医院6号楼552',1);
/*!40000 ALTER TABLE `depInclude` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `depOwn`
--

DROP TABLE IF EXISTS `depOwn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `depOwn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hosId` int(11) NOT NULL COMMENT '所属医院id',
  `name` varchar(50) DEFAULT NULL,
  `state` int(11) DEFAULT '1' COMMENT '开关，0表示关闭',
  PRIMARY KEY (`id`),
  KEY `state` (`state`,`hosId`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `depOwn`
--

LOCK TABLES `depOwn` WRITE;
/*!40000 ALTER TABLE `depOwn` DISABLE KEYS */;
INSERT INTO `depOwn` VALUES (1,1,'内科',1),(2,1,'外科',1),(3,1,'儿科',1),(4,1,'妇科',1),(5,1,'眼科',1),(6,1,'耳鼻喉科',1),(7,1,'口腔科',1),(8,1,'皮肤科',1),(9,1,'心理咨询室',1),(10,1,'中医科',1),(11,2,'内科',1),(12,2,'外科',1),(13,2,'儿科',1),(14,2,'妇科',1),(15,2,'眼科',1),(16,2,'耳鼻喉科',1),(17,2,'口腔科',1),(18,2,'皮肤科',1),(19,2,'心理咨询室',1),(20,3,'内科',1),(21,3,'外科',1),(22,3,'儿科',1),(23,3,'妇科',1),(24,3,'眼科',1),(25,3,'耳鼻喉科',1),(26,3,'口腔科',1),(27,3,'皮肤科',1),(28,3,'中医科',1);
/*!40000 ALTER TABLE `depOwn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `photo` varchar(50) DEFAULT NULL,
  `hosId` int(11) NOT NULL,
  `depId` int(11) NOT NULL,
  `depTwoId` int(11) NOT NULL,
  `position` varchar(10) NOT NULL COMMENT '职称',
  `reg` varchar(5) DEFAULT NULL COMMENT '挂号费',
  `dia` decimal(10,2) DEFAULT '0.00' COMMENT '诊查费',
  `brief` varchar(500) DEFAULT NULL,
  `state` int(11) DEFAULT '1' COMMENT '开关，0表示关闭',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'吴雨涵','/images/doctor/photo-1660734336045.jpg',1,1,1,'主治医师','60',0.00,'凭借细致耐心的品质，开朗乐观的性格，精益求精的精神，\n深受家长和孩子的喜欢以及同事的一致好评',1),(2,'沈林','/images/doctor/photo-1660735610099.jpg',1,1,2,'主任医师','65',2.00,'凭借细致耐心的品质，开朗乐观的性格，精益求精的精神，\n深受家长和孩子的喜欢以及同事的一致好评',1),(3,'陆欣汝','/images/doctor/photo-1660736395214.jpg',2,11,7,'副主任医师','50',0.00,'凭借细致耐心的品质，开朗乐观的性格，精益求精的精神，\r\n深受家长和孩子的喜欢以及同事的一致好评',1),(4,'徐秀英','/images/doctor/photo-1660736505892.jpg',3,20,12,'主治医师','60',10.00,'一切为了患者，为了患者的一切',1),(5,'秦雅涵','/images/doctor/photo-1660736533601.jpg',3,20,11,'主治医师','50',5.00,'对内科常见疾病的诊断及急、危、重症的抢救有较丰富的经验，尤其擅长支气管哮喘、慢性咳嗽的诊断和治疗，高血压、糖尿病等慢性病的控制及长期管理。在省级杂志发表论文数篇',1),(6,'任晓庆','/images/doctor/photo-1660736549094.jpg',3,20,11,'副主任医师','60',10.00,'对内科常见疾病的诊断及急、危、重症的抢救有较丰富的经验，尤其擅长支气管哮喘、慢性咳嗽的诊断和治疗，高血压、糖尿病等慢性病的控制及长期管理。在省级杂志发表论文数篇',1),(7,'徐榕润','/images/doctor/photo-1660736589744.jpg',2,11,7,'主任医师','55',10.00,'擅长脑卒中一二级预防以及头痛、良性阵发性位置性眩晕（耳石症）、痴呆等的诊断和治疗',1),(8,'徐润莎','/images/doctor/photo-1660736647337.jpg',3,28,13,'主治医师','70',0.00,'熟悉内科及肿瘤科相关诊疗工作。',1),(9,'陈强','/images/doctor/photo-1660736664353.jpg',3,28,14,'主治医师','70',0.00,'熟悉内科及肿瘤科相关诊疗工作。',1),(10,'阎苒溪','/images/doctor/photo-1660736701036.jpg',2,15,10,'主治医师','70',0.00,'擅长内科常见病、多发病的诊治。',1),(11,'贾美欣','/images/doctor/photo-1660736719056.jpg',1,2,3,'主治医师','70',0.00,'擅长内科常见病、多发病的诊治。',1),(12,'谢桂英','/images/doctor/photo-1660736732566.jpg',1,2,3,'副主任医师','60',0.00,'擅长内科常见病、多发病的诊治。',1),(13,'陆超','/images/doctor/photo-1660736741770.jpg',1,2,5,'主任医师','60',0.00,'擅长内科常见病、多发病的诊治。',1),(14,'武天昊','/images/doctor/photo-1660736750441.jpg',1,2,4,'主任医师','60',0.00,'擅长内科常见病、多发病的诊治。',1);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(30) NOT NULL,
  `type` varchar(5) NOT NULL,
  `content` varchar(200) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,'操作手感不好','使用问题','用起来卡卡的','fae2@p3puk206.com.cn','19318541963','2022-08-18 15:12:05','123456'),(2,'功能无法使用','使用问题','好多功能点击没有反应','321635426@qq.com','匿名','2022-08-20 17:50:33','123456');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `make`
--

DROP TABLE IF EXISTS `make`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `make` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `patId` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `card` varchar(20) DEFAULT NULL COMMENT '就诊卡',
  `idCard` varchar(18) DEFAULT NULL COMMENT '身份证',
  `phone` varchar(12) DEFAULT NULL,
  `type` varchar(5) DEFAULT NULL COMMENT '挂号类型',
  `price` int(11) NOT NULL,
  `state` int(11) DEFAULT '0' COMMENT '状态，0待就诊，1已完成，2以取消',
  `time` varchar(30) DEFAULT NULL COMMENT '就诊日期',
  `datetime` varchar(10) DEFAULT NULL COMMENT '时间',
  `createTime` varchar(30) DEFAULT NULL COMMENT '预约时间',
  `depName` varchar(30) DEFAULT NULL COMMENT '科室名称',
  `hosName` varchar(30) DEFAULT NULL,
  `hosId` int(11) NOT NULL,
  `depId` int(11) NOT NULL,
  `depTwoId` int(11) NOT NULL,
  `doctorName` varchar(20) DEFAULT NULL COMMENT '医生姓名',
  `doctorId` int(11) NOT NULL COMMENT '医生id',
  `position` varchar(5) DEFAULT NULL COMMENT '医生职称',
  `remarks` varchar(30) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `name` (`name`,`card`,`idCard`,`state`,`doctorId`,`patId`,`depTwoId`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `make`
--

LOCK TABLES `make` WRITE;
/*!40000 ALTER TABLE `make` DISABLE KEYS */;
INSERT INTO `make` VALUES (1,1,1,'许冰枫','202203923523','220201198302283144','14939204403','普通号',60,1,'2022年8月18日上午','9.30','2022-08-18 15:16:49','内科-神经内科','青龙东院',1,1,1,'吴雨涵',1,'主治医师','无'),(4,1,2,'吕雅晗','202203923566','610201198303035778','15612575061','专家号',60,2,'2022年8月25日上午','9.30','2022-08-21 09:06:46','内科-神经内科','青龙东院',1,1,1,'吴雨涵',1,'主治医师','不想去'),(5,1,3,'金添昊','202203923562','230101198502027045','13894114250','普通号',55,1,'2022-08-25上午','8.55','2022-08-24 08:15:03','内科-普通内科','华夏神州人民医院玄武北院',3,20,11,'秦雅涵',5,'主治医师','无'),(12,1,2,'吕雅晗','202203923566','610201198303035778','15612575061','普通号',55,1,'2022-08-25上午','9.05','2022-08-24 16:20:21','内科-普通内科','华夏神州人民医院玄武北院',3,20,11,'秦雅涵',5,'主治医师','无');
/*!40000 ALTER TABLE `make` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `message`
--

DROP TABLE IF EXISTS `message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL DEFAULT '0' COMMENT '接收消息的用户id，0表示全部用户',
  `source` varchar(20) DEFAULT NULL COMMENT '来源',
  `time` datetime DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `isread` int(11) DEFAULT '0' COMMENT '是否已读，0为未读',
  `title` varchar(20) NOT NULL,
  `content` varchar(800) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userId` (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `message`
--

LOCK TABLES `message` WRITE;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` VALUES (1,1,'管理员','2022-08-18 15:14:23','新消息',1,'反馈已收到','感谢您的反馈'),(2,1,'管理员','2022-08-18 15:26:30','退款处理',1,'您的退款申请被驳回','您的订单号为TK081518262022090870的申请被驳回，<br><br>驳回原因为：不想给你退。'),(5,1,'4','2022-08-21 09:06:46','预约成功',1,'预约挂号成功','您已成功在青龙东院预约挂号，请于2022年8月25日上午准时就诊。'),(6,1,'系统通知','2022-08-21 15:15:57','新消息',1,'预约挂号已取消','您在青龙东院预约于2022年8月25日上午的挂号已成功取消'),(7,1,'管理员','2022-08-22 15:50:39','退款处理',1,'您的退款申请已通过','您的订单号为TK081522332022179925的申请已通过，<br>退款金额为：15元，退款后余额为：0元。'),(8,1,'5','2022-08-24 08:15:03','预约成功',1,'预约挂号成功','您已成功在华夏神州人民医院玄武北院预约挂号，请于2022-08-25上午准时就诊。'),(9,1,'12','2022-08-24 16:20:21','预约成功',0,'预约挂号成功','您已成功在华夏神州人民医院玄武北院预约挂号，请于2022-08-25上午准时就诊。');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigation`
--

DROP TABLE IF EXISTS `navigation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `reco` varchar(150) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigation`
--

LOCK TABLES `navigation` WRITE;
/*!40000 ALTER TABLE `navigation` DISABLE KEYS */;
INSERT INTO `navigation` VALUES (1,'华夏神州人民医院青龙东院','0010-556632','华夏神州内乘4、5、20、24、27、49、46路高铁可直达青龙东院本部','上海市市辖区奉贤区南桥镇'),(2,'华夏神州人民医院厚土中院','0010-556689','华夏神州内乘11,23,89,555,682路高铁可直达厚土中院本部','山西省晋城市沁水县龙港镇'),(3,'华夏神州人民医院玄武北院','0010-556636','华夏神州内乘87,63,19,665,823路高铁可直达玄武北院本部','山东省潍坊市青州市何官镇');
/*!40000 ALTER TABLE `navigation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `navigationFloor`
--

DROP TABLE IF EXISTS `navigationFloor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `navigationFloor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hosId` int(11) NOT NULL,
  `floorName` varchar(10) NOT NULL,
  `content` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `navigationFloor`
--

LOCK TABLES `navigationFloor` WRITE;
/*!40000 ALTER TABLE `navigationFloor` DISABLE KEYS */;
INSERT INTO `navigationFloor` VALUES (1,1,'一楼','肿瘤内科、肿瘤外科、肿瘤妇科、骨肿瘤科、放疗科、肿瘤康复科、肿瘤综合科'),(2,1,'二楼','医全科、中医内科、中医外科、中医妇科、中医儿科、中医保健科、针灸按摩科'),(3,1,'三楼','肝病科、艾滋病科、结核病、寄生虫'),(4,2,'一楼','药剂科、护理科、体检科、检验科、急诊科、公共卫生与预防科、全科'),(5,2,'二楼','核医学科、放射科、超声科'),(6,3,'一楼','普通外科、神经外科、心胸外科、泌尿外科、心血管外科、乳腺外科、肝胆外科、器官移植、肛肠外科、烧伤科、骨外科'),(7,3,'二楼','科、产科、计划生育、妇幼保健');
/*!40000 ALTER TABLE `navigationFloor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  `docType` varchar(10) NOT NULL DEFAULT '身份证',
  `certificate` varchar(18) NOT NULL,
  `relation` varchar(2) NOT NULL,
  `card` varchar(20) NOT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `isdefault` int(11) DEFAULT '2' COMMENT '1默认，2非默认',
  `balance` decimal(10,2) DEFAULT '0.00' COMMENT '账户余额',
  `userId` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `card` (`card`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (2,'吕雅晗','身份证','610201198303035778','子女','202203923566','15612575061','内蒙古自治区乌兰察布市察哈尔右翼中旗黄羊城镇',1,5.00,1),(3,'金添昊','身份证','230101198502027045','本人','202203923562','13894114250','云南省红河哈尼族彝族自治州屏边苗族自治县新华乡',2,10.00,1);
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payOrder`
--

DROP TABLE IF EXISTS `payOrder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payOrder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` varchar(20) NOT NULL,
  `time` datetime DEFAULT NULL,
  `price` int(11) DEFAULT NULL COMMENT '总价',
  `type` varchar(10) DEFAULT NULL,
  `dep` varchar(10) DEFAULT NULL COMMENT '科室',
  `patName` varchar(10) DEFAULT NULL COMMENT '就诊人姓名',
  `card` varchar(20) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `patId` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT '0' COMMENT '0待支付，1已支付',
  PRIMARY KEY (`id`),
  KEY `orderId` (`orderId`,`state`,`patId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payOrder`
--

LOCK TABLES `payOrder` WRITE;
/*!40000 ALTER TABLE `payOrder` DISABLE KEYS */;
INSERT INTO `payOrder` VALUES (1,'JF081518502022586206','2022-08-18 15:50:58',100,'西药费','消化内科','吕雅晗','202203923523',1,2,0),(2,'JF081824232022044414','2022-08-24 18:23:04',55,'挂号费','内科-普通内科','金添昊','202203923562',1,3,0);
/*!40000 ALTER TABLE `payOrder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payOrderList`
--

DROP TABLE IF EXISTS `payOrderList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payOrderList` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `orderId` varchar(20) NOT NULL,
  `name` varchar(60) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL COMMENT '单价',
  `num` int(11) DEFAULT '1',
  `total` int(11) DEFAULT NULL COMMENT '小计',
  PRIMARY KEY (`id`),
  KEY `orderId` (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payOrderList`
--

LOCK TABLES `payOrderList` WRITE;
/*!40000 ALTER TABLE `payOrderList` DISABLE KEYS */;
INSERT INTO `payOrderList` VALUES (1,'JF081518502022586206','阿莫西林',30.00,2,60),(2,'JF081518502022586206','胶囊',20.00,2,40),(3,'JF081824232022044414','挂号费',55.00,1,55);
/*!40000 ALTER TABLE `payOrderList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recorder`
--

DROP TABLE IF EXISTS `recorder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `recorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auantity` decimal(10,2) NOT NULL COMMENT '充值金额',
  `card` varchar(20) NOT NULL,
  `payType` varchar(10) DEFAULT '在线支付',
  `time` datetime DEFAULT NULL,
  `orderId` varchar(35) DEFAULT NULL COMMENT '支付订单号',
  `patName` varchar(10) DEFAULT NULL,
  `userId` int(11) NOT NULL,
  `patId` int(11) NOT NULL COMMENT '就诊人id',
  `balance` decimal(10,2) NOT NULL COMMENT '充值完成余额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recorder`
--

LOCK TABLES `recorder` WRITE;
/*!40000 ALTER TABLE `recorder` DISABLE KEYS */;
INSERT INTO `recorder` VALUES (1,65.00,'202203923523','微信支付','2022-08-18 15:19:57','CZ081518192022578557','许冰枫',1,1,65.00),(2,15.00,'202203923566','微信支付','2022-08-21 15:50:00','CZ081521502022007675','吕雅晗',1,2,35.00),(3,50.00,'202203923566','微信支付','2022-08-22 20:30:40','CZ082022302022401864','吕雅晗',1,2,50.00),(4,10.00,'202203923566','微信支付','2022-08-22 20:31:22','CZ082022312022223846','吕雅晗',1,2,60.00),(5,10.00,'202203923562','微信支付','2022-08-22 20:36:05','CZ082022362022056758','金添昊',1,3,10.00);
/*!40000 ALTER TABLE `recorder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refund`
--

DROP TABLE IF EXISTS `refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `refund` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `time` datetime DEFAULT NULL,
  `orderId` varchar(20) NOT NULL,
  `name` varchar(15) DEFAULT NULL,
  `card` varchar(20) NOT NULL,
  `balance` decimal(10,2) NOT NULL COMMENT '余额',
  `money` decimal(10,2) NOT NULL COMMENT '退款金额',
  `userId` int(11) DEFAULT NULL,
  `patId` int(11) DEFAULT NULL,
  `state` int(11) DEFAULT '0' COMMENT '0待处理，1已退款，2驳回',
  PRIMARY KEY (`id`),
  KEY `orderId` (`orderId`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refund`
--

LOCK TABLES `refund` WRITE;
/*!40000 ALTER TABLE `refund` DISABLE KEYS */;
INSERT INTO `refund` VALUES (1,'2022-08-18 15:26:09','TK081518262022090870','吕雅晗','202203923523',0.00,5.00,1,2,2),(2,'2022-08-22 15:33:17','TK081522332022179925','吕雅晗','202203923566',0.00,15.00,1,2,1);
/*!40000 ALTER TABLE `refund` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `swiper`
--

DROP TABLE IF EXISTS `swiper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `swiper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imgUrl` varchar(50) DEFAULT NULL,
  `detId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `swiper`
--

LOCK TABLES `swiper` WRITE;
/*!40000 ALTER TABLE `swiper` DISABLE KEYS */;
INSERT INTO `swiper` VALUES (1,'/images/swiper/swiperImg-1660737121955.jpg',1),(2,'/images/swiper/swiperImg-1660737502591.png',2),(3,'/images/swiper/swiperImg-1660737716851.jpg',3);
/*!40000 ALTER TABLE `swiper` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(32) NOT NULL,
  `name` varchar(20) NOT NULL,
  `gender` int(11) NOT NULL DEFAULT '0',
  `age` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(11) DEFAULT NULL,
  `avatar` varchar(50) DEFAULT NULL,
  `createTime` datetime DEFAULT NULL,
  `state` int(11) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'123456','e50de14051afd6aacd8d1560f2f08579','测试用户',0,18,'749038898@qq.com','18686979779','/images/avatar/avatar-1660998773847.jpg','0000-00-00 00:00:00',1),(11,'12345678','78d609a308db4a83d77eac6f9d486262','墨羽晨',0,20,'8c1f@6069n6.xyz','18374578913','/images/default/boy.jpeg','2022-08-19 17:54:28',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'register'
--

--
-- Dumping routines for database 'register'
--
/*!50003 DROP PROCEDURE IF EXISTS `getArrange` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`register`@`localhost` PROCEDURE `getArrange`(in Intime date,in Inpage int,in Inlimit int)
begin
select 
     a.id,a.doctorName,a.doctorId,a.hosName,a.hosId,a.depName,
    (select id from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as id1,
	(select time from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as time1,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as MtimeSegment1,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Mnum1,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Msurplus1,
	(select Mstate from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Mstate1,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as AtimeSegment1,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Anum1,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Asurplus1,
	(select Astate from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Astate1,
    (select id from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as id2,
    (select time from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as time2,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as MtimeSegment2,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Mnum2,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Msurplus2,
	(select Mstate from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Mstate2,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as AtimeSegment2,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Anum2,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Asurplus2,
	(select Astate from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Astate2,
    (select id from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as id3,
    (select time from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as time3,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as MtimeSegment3,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Mnum3,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Msurplus3,
	(select Mstate from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Mstate3,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as AtimeSegment3,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Anum3,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Asurplus3,
	(select Astate from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Astate3,
    (select id from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as id4,
    (select time from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as time4,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as MtimeSegment4,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Mnum4,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Msurplus4,
	(select Mstate from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Mstate4,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as AtimeSegment4,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Anum4,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Asurplus4,
	(select Astate from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Astate4,
    (select id from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as id5,
    (select time from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as time5,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as MtimeSegment5,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Mnum5,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Msurplus5,
	(select Mstate from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Mstate5,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as AtimeSegment5,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Anum5,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Asurplus5,
	(select Astate from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Astate5,
    (select id from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as id6,
    (select time from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as time6,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as MtimeSegment6,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Mnum6,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Msurplus6,
	(select Mstate from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Mstate6,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as AtimeSegment6,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Anum6,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Asurplus6,
	(select Astate from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Astate6,
    (select id from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as id7,
    (select time from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as time7,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as MtimeSegment7,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Mnum7,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Msurplus7,
	(select Mstate from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Mstate7,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as AtimeSegment7,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Anum7,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Asurplus7,
	(select Astate from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Astate7
 from arrange a where time between Intime and date_add(Intime,interval 6 day) and doctorId = a.doctorId  group by doctorId limit Inpage,Inlimit;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getArrangeById` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`register`@`localhost` PROCEDURE `getArrangeById`(in Intime date,in Inid int)
begin
select 
    a.id,a.doctorName,a.doctorId,a.hosName,a.hosId,a.depName,
    (select id from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as id1,
	(select time from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as time1,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as MtimeSegment1,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Mnum1,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Msurplus1,
	(select Mstate from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Mstate1,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as AtimeSegment1,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Anum1,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Asurplus1,
	(select Astate from arrange where time = date_add(Intime,interval 0 day) and doctorId = a.doctorId) as Astate1,
    (select id from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as id2,
    (select time from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as time2,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as MtimeSegment2,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Mnum2,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Msurplus2,
	(select Mstate from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Mstate2,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as AtimeSegment2,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Anum2,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Asurplus2,
	(select Astate from arrange where time = date_add(Intime,interval 1 day) and doctorId = a.doctorId) as Astate2,
    (select id from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as id3,
    (select time from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as time3,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as MtimeSegment3,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Mnum3,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Msurplus3,
	(select Mstate from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Mstate3,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as AtimeSegment3,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Anum3,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Asurplus3,
	(select Astate from arrange where time = date_add(Intime,interval 2 day) and doctorId = a.doctorId) as Astate3,
    (select id from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as id4,
    (select time from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as time4,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as MtimeSegment4,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Mnum4,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Msurplus4,
	(select Mstate from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Mstate4,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as AtimeSegment4,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Anum4,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Asurplus4,
	(select Astate from arrange where time = date_add(Intime,interval 3 day) and doctorId = a.doctorId) as Astate4,
    (select id from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as id5,
    (select time from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as time5,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as MtimeSegment5,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Mnum5,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Msurplus5,
	(select Mstate from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Mstate5,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as AtimeSegment5,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Anum5,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Asurplus5,
	(select Astate from arrange where time = date_add(Intime,interval 4 day) and doctorId = a.doctorId) as Astate5,
    (select id from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as id6,
    (select time from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as time6,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as MtimeSegment6,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Mnum6,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Msurplus6,
	(select Mstate from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Mstate6,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as AtimeSegment6,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Anum6,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Asurplus6,
	(select Astate from arrange where time = date_add(Intime,interval 5 day) and doctorId = a.doctorId) as Astate6,
    (select id from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as id7,
    (select time from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as time7,
	(select if(Mstate = 1,'休息',MtimeSegment) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as MtimeSegment7,
	(select if(Mstate = 1,'休息',Mnum) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Mnum7,
	(select if(Mstate = 1,'休息',Msurplus) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Msurplus7,
	(select Mstate from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Mstate7,
	(select if(Astate = 1,'休息',AtimeSegment) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as AtimeSegment7,
	(select if(Astate = 1,'休息',Anum) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Anum7,
	(select if(Astate = 1,'休息',Asurplus) from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Asurplus7,
	(select Astate from arrange where time = date_add(Intime,interval 6 day) and doctorId = a.doctorId) as Astate7
 from arrange a where time between Intime and date_add(Intime,interval 6 day) and doctorId = Inid  group by doctorId;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getStatistics` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`register`@`localhost` PROCEDURE `getStatistics`()
begin
select 
    (select count(id) from make where datediff(createTime,now()) = 0) as appointments,
    (select if(sum(money),sum(money),0) from refund where datediff(time,now()) = 0) as refund,
    (select if(sum(auantity),sum(auantity),0) from recorder where datediff(time,now()) = 0) as recharge,
    (select if(sum(price),sum(price),0) from make where datediff(createTime,now()) = 0) as outpatient,
    (select count(id) from users where datediff(createTime,now()) = 0) as users
;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `patDefMod` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`register`@`localhost` PROCEDURE `patDefMod`(in userId int,in pid int)
begin
	update patient set isdefault = 2 where userId = userId;
    update patient set isdefault = 1 where id = pid;
 end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-09-14  2:30:01
